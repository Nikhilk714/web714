package casestudy1;

import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class TicketApplication {

	public static void main(String[] args) throws ClassNotFoundException,SQLException,ParseException {

		Scanner s1 = new Scanner(System.in);
		
		TrainDAO t1 = new TrainDAO();
		
		Train PassengerTrain;
		
		// ----------- Train NO. Verification -----------
		
		System.out.println("Enter the Train Number: ");
		int trainno = s1.nextInt();
		PassengerTrain =t1.findTrain(trainno);
		if(PassengerTrain ==null) {
			s1.close();
			return;		
		}
		
		//---------------Data Verification --------------
		
		System.out.println("Enter the Travel Date:");
		String travelDate = s1.next();
		
		DateTimeFormatter formatter_1 = DateTimeFormatter.ofPattern("DD/MM/YYYY");
		LocalDate date1 = LocalDate.parse(travelDate, formatter_1);
		LocalDate TodayDate = LocalDate.now();
		
		if(date1.isBefore(TodayDate)){
			s1.close();
			System.out.println("Travel date is before current date");
			return;
		}
		
	
		
		//--------------Store date and time data in Ticket -------------
		Ticket passengerTicket = new Ticket(date1 ,PassengerTrain);
		
		//Enter the information of passenger
		System.out.println("Enter number of passengers:");
		int noOfPassengers = s1.nextInt();
		

		for (int i=0; i<noOfPassengers;i++) {
			
			System.out.println("Enter Passenger Name:");
			String Passengername = s1.next();
			
			System.out.println("Enter Passenger Age:");
			int Passengerage = s1.nextInt();
			
			System.out.println("Enter Gender(M/F):");
			char Passengergender = s1.next().charAt(0);
			PassengerTicket.addPassenger( Passengername, Passengerage, Passengergender);

		}

		System.out.println(PassengerTicket.generatePNR());
		PassengerTicket.generateTicket();
		PassengerTicket.writeTicket();
		s1.close();
	}
}
