package com.day11.mongo.demo;

import java.util.Iterator;

import org.bson.Document;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class JDBCmongodemo {

	public static void main(String[] args) {

		MongoClient mongoClient = new MongoClient("localhost",27017);

		MongoDatabase database = mongoClient.getDatabase("moviedb");

		MongoCollection<Document> collection = database.getCollection("movies");

		FindIterable<Document> iterDocument = collection.find();

		Iterator iterator = iterDocument.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());			
		}

		MongoCursor<Document> cursor = collection.find().iterator();
		while(cursor.hasNext()) {
			Document movie = cursor.next();
			System.out.println(movie.get("name"));			
		}

		/*MongoCursor<Document> cursor1 = collection.find().iterator();
		while(cursor1.hasNext()) {                                          //for category display
			Document movie = cursor1.next();
			System.out.println(movie.get("category"));			
		}*/

		/*MongoCursor<Document> cursor2 = collection.find().iterator();
		while(cursor2.hasNext()) {
			Document movie = cursor2.next();                                   //for year display
			System.out.println(movie.get("year"));			
		} */
	}
}
